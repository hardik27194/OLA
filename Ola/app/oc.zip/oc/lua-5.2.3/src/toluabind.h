/*
** Lua binding: tolua
** Generated automatically by tolua++-1.0.92 on Sun Feb 15 22:29:48 2009.
*/

/* Exported function */
TOLUA_API int  tolua_tolua_open (lua_State* tolua_S);

