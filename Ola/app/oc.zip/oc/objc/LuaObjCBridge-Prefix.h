/*
 *
 * LuaObjCBridge-Prefix.h
 *
 * By Tom McClean, 2005/2006
 *
 * This file is public domain. It is provided without any warranty whatsoever,
 * and may be modified or used without attribution.
 *
 */

#ifdef __OBJC__
	#import <Foundation/Foundation.h>	
#endif