#import <Foundation/Foundation.h>
#import "CSS.h"

@implementation CSS
@synthesize cssString,name,bottom,left,right,top,position,display,visibility,verticalAlign,sIndex,width,height,weight,textAlign,orientation,color,styles;

	- (CSS *) init:(NSString *)cssString
	{
		self.cssString=cssString;
		self.display=YES;
		self.visibility=YES;
		self.styles=[NSMutableDictionary dictionaryWithCapacity:10];  
		[self parse:cssString];
		return self;

	}
	
	- (void)  parse:(NSString *)css
	{
		//should use Tokennizer to parse the CSS string
		if(css==nil || [css isEqualToString:@""])return;
		NSArray *items=[css componentsSeparatedByString:@";"];
		//for(int i=0;i < items.count;i++)
		int i=0;
		for(NSString *s in items)
		{
			//NSString *s=[items objectAtIndex:i];
			NSLog(@"s%d=%@",i++,s);
			if(s==nil || [s compare:@""] == NSOrderedSame)continue;
			//NSRange *range=[s rangeOfString:@":"];
			//int pos=;
			//if(pos<0)continue;

			NSArray *pair=[s componentsSeparatedByString:@":"];
			if([pair count]<=1)continue;
			NSString *name=[pair objectAtIndex:0];
			NSString *value=[pair objectAtIndex:1];
			[self.styles setObject:value forKey:name];
			//styles.put(s.substring(0,pos), s.substring(pos+1));
			//System.out.println("CSS:"+s.substring(0,pos)+"="+ s.substring(pos+1));
			//parse(s.substring(0,pos), s.substring(pos+1));
			[self parse:value forKey:name];
		}
		NSLog(@"test...");
		NSLog(@"left=%d",self.left);
		NSLog(@"test1...");
	}
	- (BOOL) compare:(NSString *)str1 withString:(NSString *)str2
	{
		return [str1 compare:str2 options:NSCaseInsensitiveSearch | NSNumericSearch] == NSOrderedSame;
	}
	- (void)parse:(NSString *)value forKey:(NSString *)name
	{
		if([self compare:name withString:@"left"]) self.left=[CSS parseInt:value];
		else if([self compare:name withString:@"right"]) self.right=[CSS parseInt:value];
		else if([self compare:name withString:@"top"]) self.top=[CSS parseInt:value];
		else if([self compare:name withString:@"bottom"]) self.bottom=[CSS parseInt:value];
		else if([self compare:name withString:@"vertical-Align"] || [self compare:name withString:@"valign"]) self.verticalAlign=value;
		else if([self compare:name withString:@"text-Align"] || [self compare:name withString:@"align"]) self.textAlign=value;
		else if([self compare:name withString:@"text-color"] || [self compare:name withString:@"color"]) self.color=[CSS parseColor:value];
		
		else if([self compare:name withString:@"weight"]) self.weight=[CSS parseInt:value];
		else if([self compare:name withString:@"orientation"]) self.orientation=value;
		
	}
	
	- (NSString *)getStyleValue:(NSString *)styleName
	{
		NSLog(@"name=%@",styleName);
		return [self.styles objectForKey:styleName];
	}
	
	+ (int) parseColor:(NSString *)color
	{
		//UIColor *color = [CSS hexStringToColor:color];
		
		return [CSS hexStringToColor:color];
	}
	+ (int) parseInt:(NSString *)number
	{
		/*
		@try
		{
		*/
		NSLog(@"string=%@",number);
		if([number hasSuffix:@"px"])number=[number substringToIndex:(number.length-2)];
		if([number hasSuffix:@"dp"])number=[number substringToIndex:(number.length-2)];

		//NSMutableString *string = [NSMutableString stringWithString:number];         
		//[string replaceCharactersInRange:[string rangeOfString:@"px"] withString:@""];         
		//number = [NSString stringWithString:string];

		//string = [NSMutableString stringWithString:number];         
		//[string replaceCharactersInRange:[string rangeOfString:@"dp"] withString:@""];         
		//number = [NSString stringWithString:string];
		//number=number.replaceAll("[pP][xX]", "");
		//number=number.replaceAll("[dD][pP]", "");
		return [number intValue];
		/*
		}
		@catch (NSException  *e)
		{
			return 0;
		}
		*/
	}
	+ (NSString *) parseImageUrl:(NSString *)url
	{
		if([url hasPrefix:@"url"])
		{
			url=[url substringWithRange:NSMakeRange(4, url.length-1)];
		}
		
		return url;
	}
- (void) dealloc {
 
	////[aBook release];
	//[currentElementValue release];
	[super dealloc];
}


+(int) hexStringToColor: (NSString *) stringToConvert 
{
	/*
	NSString *cString = [[stringToConvert stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
	// String should be 6 or 8 characters         
	if ([cString length] < 6) return [UIColor blackColor];      
	// strip 0X if it appears      
	if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];      
	if ([cString hasPrefix:@"#"]) cString = [cString substringFromIndex:1];      
	if ([cString length] != 6) return [UIColor blackColor];         
	// Separate into r, g, b substrings         
	NSRange range;      
	range.location = 0;      
	range.length = 2;     
	NSString *rString = [cString substringWithRange:range];      
	range.location = 2;      
	NSString *gString = [cString substringWithRange:range];      
	range.location = 4;      
	NSString *bString = [cString substringWithRange:range];      
	// Scan values      
	unsigned int r, g, b;         
	[[NSScanner scannerWithString:rString] scanHexInt:&r];      
	[[NSScanner scannerWithString:gString] scanHexInt:&g];      
	[[NSScanner scannerWithString:bString] scanHexInt:&b];   
	return [UIColor colorWithRed:((float) r / 255.0f)                                  
				green:((float) g / 255.0f)                                   
				blue:((float) b / 255.0f)                                  
				alpha:1.0f]; 
				*/
	return [CSS colorStringToInt:stringToConvert];

} 

+ (int)colorStringToInt:(NSString *)colorStrig  

{ 
	colorStrig=[colorStrig substringFromIndex:1];
return [NSString stringWithFormat:@"%d",strtoul([colorStrig UTF8String],0,16)]; 

/*
    const char *cstr; 

    int iPosition = 0; 

    int nColor = 0; 

     cstr = [colorStrig UTF8String]; 

    
    //�ж��Ƿ���#�� 

    if (cstr[0] == '#') iPosition = 1;//��#�ţ���ӵ�1λ��ʼ����ɫֵ��������Ϊ��һλ������ɫֵ 

    else iPosition = 0; 

     
    //��1λ��ɫֵ 

    iPosition = iPosition + colorNo*2; 

    if (cstr[iPosition] >= '0' && cstr[iPosition] < '9') nColor = (cstr[iPosition] - '0') * 16;

    else  nColor = (cstr[iPosition] - 'A' + 10) * 16;

    
    //��2λ��ɫֵ 

    iPosition++; 

    if (cstr[iPosition] >= '0' && cstr[iPosition] < '9') nColor = nColor + (cstr[iPosition] - '0');

    else nColor = nColor + (cstr[iPosition] - 'A' + 10);

    
    return nColor; 
	*/

}



int main (int argc, const char *argv[]) 
{  
    NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];  

	CSS *parser = [[CSS alloc] init:@"left:10PX;right:20Dp;color:#FFCC00"];
	if(parser==nil)
	{
	NSLog(@"cs is nil");
	}
	int l=parser.left;
	NSLog(@"left=%d",[CSS colorStringToInt:@"#CCCCCC"]);
	NSString *lefts=[parser getStyleValue:@"left"];
	NSLog(@"left=%d",parser.left);
	NSLog(@"right=%d",parser.right);
	NSLog(@"color=%d",parser.color);
	
	NSLog(@"No Errors");
    [pool drain];  

    return 0;  
}
@end