gcc -g -o $1 $1.m -I/GNUstep/System/Library/Headers -fconstant-string-class=NSConstantString -L/GNUstep/System/Library/Libraries  -lobjc -lgnustep-base  -enable-auto-import -std=c99 -fobjc-exceptions /GNUstep/System/Library/Libraries/liblua.a 




