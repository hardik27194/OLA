#import <Foundation/Foundation.h>
@interface CSS : NSObject {
    NSString *cssString;
	
	NSString *name;
	
	int bottom;
	int left;
	int right;
	int top;
	NSString *position;
	BOOL display;
	BOOL visibility;
	NSString *verticalAlign;
	int sIndex;
	
	
	int width;
	int height;
	int weight;
	
	//text position
	NSString *textAlign;
	NSString *orientation;
	
	int color;
	
	NSMutableDictionary * styles;

}


@property (nonatomic,retain)    NSString *cssString;
	
@property (nonatomic)	NSString *name;
	
@property (nonatomic)	int bottom;
@property (nonatomic)	int left;
@property (nonatomic)	int right;
@property (nonatomic)	int top;
@property (nonatomic)	NSString *position;
@property (nonatomic)	BOOL display;
@property (nonatomic)	BOOL visibility;
@property (nonatomic)	NSString *verticalAlign;
@property (nonatomic)	int sIndex;
	
	
@property (nonatomic)	int width;
@property (nonatomic)	int height;
@property (nonatomic)	int weight;
	
	//text position
@property (nonatomic)	NSString *textAlign;
@property (nonatomic)	NSString *orientation;
	
@property (nonatomic)	int color;
	
@property (nonatomic)	NSMutableDictionary * styles;

- (CSS *)init:(NSString *)cssString;
- (NSString *) getStyleValue:(NSString *)styleName;
+ (int) parseColor:(NSString *)color;
+ (int) parseInt:(NSString *)number;
+ (NSString *)parseImageUrl:(NSString *)url;


@end