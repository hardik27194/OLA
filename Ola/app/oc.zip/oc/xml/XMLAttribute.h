#import <Foundation/Foundation.h>
@interface XMLAttribute:NSObject {
   NSString  *name;
   NSString  *value;
}
@property (nonatomic, retain) NSString  *name;
@property (nonatomic, retain) NSString  *value;

@end
