#import "XMLText.h"
#import <Foundation/Foundation.h>

@implementation XMLText
@synthesize value;
- (void)dealloc {
   [value release];
    [super dealloc];
}
@end
