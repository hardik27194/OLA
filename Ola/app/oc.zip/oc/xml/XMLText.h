#import <Foundation/Foundation.h>
@interface XMLText:NSObject {
   NSString  *value;
}
@property (nonatomic, retain) NSString  *value;

@end
