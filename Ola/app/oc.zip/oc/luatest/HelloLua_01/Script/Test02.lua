function func_Add(x, y)
   local test=CTest:new();
   test:SetData("Hello ,World!");
   test:GetData();
   return x,y; --ϸ�� : ..
end