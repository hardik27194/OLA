// XMLParser.h
//#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
@interface luaTest : NSObject {
}
@end